data_input <- "data/GSE131907/"
data_save <- "results/GSE131907/data/"
figure_save <- "results/GSE131907/figures/"

source("functions/functions.R")
check_dir_exists(data_save)
check_dir_exists(figure_save)

if (!file.exists(paste0(data_save, "seurat_object.rds"))) {
  counts <- readRDS(
    paste0(data_input, "GSE131907_Lung_Cancer_raw_UMI_matrix.rds")
  )
  meta_data <- read.table(
    paste0(data_input, "GSE131907_Lung_Cancer_cell_annotation.txt"),
    sep = "\t",
    header = TRUE,
    row.names = 1
  )
  meta_data <- meta_data[which(
    meta_data$Cell_type != "Undetermined"
  ), ]
  meta_data <- meta_data[which(
    meta_data$Cell_subtype != "Undetermined"
  ), ]
  samples_normal <- c(
    "LUNG_N01",
    "LUNG_N06",
    "LUNG_N08",
    "LUNG_N09",
    "LUNG_N18",
    "LUNG_N19",
    "LUNG_N20",
    "LUNG_N28",
    "LUNG_N30",
    "LUNG_N31",
    "LUNG_N34"
  )
  samples_IA <- c(
    "LUNG_T06",
    "LUNG_T18",
    "LUNG_T19",
    "LUNG_T20",
    "LUNG_T25",
    "LUNG_T30"
  )
  samples_IA3 <- c(
    "LUNG_T34"
  )
  samples_IB <- c(
    "LUNG_T08"
  )
  samples_IIA <- c(
    "LUNG_T09"
  )
  samples_IIIA <- c(
    "LUNG_T28",
    "LUNG_T31"
  )
  samples_IV <- c(
    "EBUS_06",
    "EBUS_28",
    "EBUS_49",
    "BRONCHO_58"
  )

  meta_data$stage <- "Undefinite"

  meta_data$stage[meta_data$Sample %in% samples_normal] <- "normal"
  meta_data$stage[meta_data$Sample %in% samples_IA] <- "IA"
  meta_data$stage[meta_data$Sample %in% samples_IA3] <- "IA3"
  meta_data$stage[meta_data$Sample %in% samples_IB] <- "IB"
  meta_data$stage[meta_data$Sample %in% samples_IIA] <- "IIA"
  meta_data$stage[meta_data$Sample %in% samples_IIIA] <- "IIIA"
  meta_data$stage[meta_data$Sample %in% samples_IV] <- "IV"
  meta_data <- meta_data[which(meta_data$stage != "Undefinite"), ]

  meta_data$Sample_con <- ifelse(
    meta_data$stage == "normal",
    "Normal",
    "Tumor"
  )

  seurat_object <- Seurat::CreateSeuratObject(
    counts = counts[, intersect(colnames(counts), rownames(meta_data))],
    meta.data = meta_data
  )

  saveRDS(
    seurat_object,
    paste0(data_save, "seurat_object.rds")
  )
}

if (!file.exists(paste0(data_save, "seurat_object.rds"))) {
  seurat_object <- readRDS(
    paste0(data_save, "seurat_object.rds")
  )
  counts <- seurat_object@assays$RNA@counts
  meta_data <- seurat_object@meta.data

  meta_data <- meta_data[c(
    which(meta_data$Sample_Origin == "tLung"),
    which(meta_data$Sample_Origin == "tL/B")
  ), ]

  counts <- counts[, intersect(colnames(counts), rownames(meta_data))]

  seurat_object <- Seurat::CreateSeuratObject(
    counts = counts,
    meta.data = meta_data
  )
  saveRDS(
    seurat_object,
    paste0(data_save, "seurat_object_tLung&tL_B.rds")
  )
}

if (!file.exists(paste0(data_save, "seurat_object_tLung&tL_B.rds"))) {
  seurat_object <- readRDS(
    paste0(data_save, "seurat_object_tLung&tL_B.rds")
  )

  dims_num <- 1:50
  resolution <- 1
  seurat_object <- Seurat::FindVariableFeatures(seurat_object)
  seurat_object <- Seurat::NormalizeData(seurat_object)
  seurat_object <- Seurat::ScaleData(seurat_object)
  seurat_object <- Seurat::RunPCA(seurat_object)
  seurat_object <- Seurat::FindNeighbors(seurat_object, dims = dims_num)
  seurat_object <- Seurat::FindClusters(seurat_object, resolution = resolution)
  seurat_object <- Seurat::RunUMAP(seurat_object, dims = dims_num)

  # seurat_object <- Standard_SCP(seurat_object)

  seurat_object <- Integration_SCP(
    srtMerge = seurat_object,
    batch = "Sample",
    integration_method = "Harmony",
    linear_reduction_dims_use = 1:50,
    cluster_resolution = 1,
    seed = 2024
  )

  saveRDS(
    seurat_object,
    file = paste0(data_save, "seurat_object_tLung&tL_B_processed.rds")
  )
}

if (!file.exists(
  paste0(data_save, "seurat_object_tLung&tL_B_Epithelial cells_processed.rds")
)) {
  seurat_object <- readRDS(
    file = paste0(data_save, "seurat_object_tLung&tL_B_processed.rds")
  )
  counts <- seurat_object@assays$RNA@counts
  meta_data <- seurat_object@meta.data
  meta_data <- meta_data[which(meta_data$Cell_type == "Epithelial cells"), ]
  meta_data <- meta_data[which(meta_data$Cell_subtype != "tS3"), ]
  seurat_object_Epithelial <- CreateSeuratObject(
    counts = counts[, intersect(colnames(counts), rownames(meta_data))],
    meta.data = meta_data
  )

  dims_num <- 1:30
  resolution <- 0.5
  seurat_object_Epithelial <- Seurat::FindVariableFeatures(seurat_object_Epithelial)
  seurat_object_Epithelial <- Seurat::NormalizeData(seurat_object_Epithelial)
  seurat_object_Epithelial <- Seurat::ScaleData(seurat_object_Epithelial)
  seurat_object_Epithelial <- Seurat::RunPCA(seurat_object_Epithelial)
  seurat_object_Epithelial <- Seurat::FindNeighbors(seurat_object_Epithelial, dims = dims_num)
  seurat_object_Epithelial <- Seurat::FindClusters(seurat_object_Epithelial, resolution = resolution)
  seurat_object_Epithelial <- Seurat::RunUMAP(seurat_object_Epithelial, dims = dims_num)

  # seurat_object_Epithelial <- Standard_SCP(seurat_object_Epithelial)

  seurat_object_Epithelial <- Integration_SCP(
    srtMerge = seurat_object_Epithelial,
    batch = "Sample",
    integration_method = "Harmony",
    linear_reduction_dims_use = 1:50,
    cluster_resolution = 1,
    seed = 2024
  )
  saveRDS(
    seurat_object_Epithelial,
    file = paste0(
      data_save,
      "seurat_object_tLung&tL_B_Epithelial cells_processed.rds"
    )
  )
}


seurat_object <- readRDS(
  file = paste0(data_save, "seurat_object_tLung&tL_B_processed.rds")
)


p1 <- FeatureDimPlot(
  srt = seurat_object,
  features = c("ADAM32"),
  reduction = "UMAP",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "GSE131907",
  cells.highlight = TRUE
)
p1
ggsave(
  p1,
  filename = paste0(
    figure_save,
    "figure_01_FeatureDimPlot_tLung&tL_B_ADAM32.pdf"
  ),
  width = 3.5,
  height = 3.5
)

p2 <- CellDimPlot(
  srt = seurat_object,
  group.by = c(
    "Sample",
    # "stage",
    # "Cell_subtype",
    "Cell_type"
  ),
  label = TRUE,
  reduction = "UMAP",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
)
p2
ggsave(
  p2,
  filename = paste0(
    figure_save,
    "figure_02_CellDimPlot_tLung&tL_B.pdf"
  ),
  width = 12,
  height = 8
)

p3 <- FeatureDimPlot(
  srt = seurat_object,
  features = c("ADAM32"),
  reduction = "harmony",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "GSE131907",
  cells.highlight = TRUE
)
p3
ggsave(
  p3,
  filename = paste0(
    figure_save,
    "figure_03_FeatureDimPlot_tLung&tL_B_ADAM32_Harmony.pdf"
  ),
  width = 3.5,
  height = 3.5
)

p4 <- CellDimPlot(
  srt = seurat_object,
  group.by = c(
    "Sample",
    # "stage",
    # "Cell_subtype",
    "Cell_type"
  ),
  label = TRUE,
  reduction = "harmony",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
)
p4
ggsave(
  p4,
  filename = paste0(
    figure_save,
    "figure_04_CellDimPlot_tLung&tL_B_Harmony.pdf"
  ),
  width = 12,
  height = 8
)

seurat_object_Epithelial <- readRDS(
  file = paste0(
    data_save,
    "seurat_object_tLung&tL_B_Epithelial cells_processed.rds"
  )
)
seurat_object_Epithelial$Cell_subtype[
  which(seurat_object_Epithelial$Cell_subtype == "Malignant cells")
] <- "tS3"



p5 <- FeatureDimPlot(
  srt = seurat_object_Epithelial,
  features = c("ADAM32"),
  reduction = "UMAP",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "GSE131907",
  cells.highlight = TRUE
)
p5
ggsave(
  p5,
  filename = paste0(
    figure_save,
    "figure_01_FeatureDimPlot_tLung&tL_B_Epithelial_ADAM32.pdf"
  ),
  width = 3.5,
  height = 3.5
)

p6 <- CellDimPlot(
  srt = seurat_object_Epithelial,
  group.by = c(
    "Sample",
    # "stage",
    "Cell_subtype"
    # "Cell_type"
  ),
  label = TRUE,
  reduction = "UMAP",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
)
p6
ggsave(
  p6,
  filename = paste0(
    figure_save,
    "figure_02_CellDimPlot_tLung&tL_B_Epithelial.pdf"
  ),
  width = 12,
  height = 8
)

p7 <- FeatureDimPlot(
  srt = seurat_object_Epithelial,
  features = c("ADAM32"),
  reduction = "harmony",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "GSE131907",
  # add_density = TRUE,
  cells.highlight = TRUE
)
p7
ggsave(
  p7,
  filename = paste0(
    figure_save,
    "figure_03_FeatureDimPlot_tLung&tL_B_Epithelial_ADAM32_Harmony.pdf"
  ),
  width = 3.5,
  height = 3.5
)

p8 <- CellDimPlot(
  srt = seurat_object_Epithelial,
  group.by = c(
    "Sample",
    # "stage",
    "Cell_subtype"
    # "Cell_type"
  ),
  label = TRUE,
  reduction = "harmony",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
)
p8
ggsave(
  p8,
  filename = paste0(
    figure_save,
    "figure_04_CellDimPlot_tLung&tL_B_Epithelial_Harmony.pdf"
  ),
  width = 12,
  height = 8
)

p9 <- FeatureStatPlot(
  seurat_object_Epithelial,
  stat.by = c("ADAM32"),
  group.by = "Cell_subtype",
  plot_type = "bar"
)
ggsave(
  p9,
  filename = paste0(
    figure_save,
    "figure_05_FeatureStatPlot-bar_tLung&tL_B_Epithelial_Harmony.pdf"
  ),
  width = 5,
  height = 5
)

seurat_object_Epithelial <- RunSlingshot(
  srt = seurat_object_Epithelial,
  group.by = "Cell_subtype",
  reduction = "harmony"
)

p10 <- FeatureDimPlot(
  seurat_object_Epithelial,
  features = paste0("Lineage", 1),
  # lineages = paste0("Lineage", 1),
  reduction = "harmony",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  subtitle = "GSE131907"
)
p10
ggsave(
  p10,
  filename = paste0(
    figure_save,
    "figure_06_Pseudotime_Epithelial cells.pdf"
  ),
  width = 3.5,
  height = 3.5
)

seurat_object_Epithelial <- RunDynamicFeatures(
  srt = seurat_object_Epithelial,
  lineages = c("Lineage1"),
  n_candidates = 100
)
features_sel <- names(seurat_object_Epithelial@tools$DynamicFeatures$family)
seurat_object_Epithelial <- RunDynamicFeatures(
  srt = seurat_object_Epithelial,
  features = c(
    features_sel[1:49],
    "ADAM32"
  ),
  lineages = c("Lineage1"),
  n_candidates = 100
)

ht2 <- DynamicHeatmap(
  srt = seurat_object_Epithelial,
  # features = c("ADAM32"),
  lineages = c("Lineage1"),
  show_row_names = TRUE,
  min_expcells = 0,
  r.sq = 0,
  dev.expl = 0,
  padjust = 1,
  # use_fitted = TRUE,
  n_split = 3,
  # reverse_ht = "Lineage1",
  species = "Homo_sapiens",
  # db = "GO_BP",
  db = "GO_BP",
  anno_terms = TRUE,
  # anno_keys = TRUE,
  # anno_features = TRUE,
  heatmap_palette = "viridis",
  cell_annotation = "Cell_subtype",
  separate_annotation = list("Cell_subtype"), # , c("ADAM32")
  separate_annotation_palette = c("Paired"), # , "Set1"
  pseudotime_label = 25,
  pseudotime_label_color = "red",
  height = 7,
  width = 3
)
ht2$plot
# ht3 <- DynamicHeatmap(
#   srt = seurat_object_Epithelial,
#   lineages = "Lineage1",
#   features = c("ADAM32"),
#   use_fitted = TRUE,
#   cell_annotation = "Cell_subtype",
#   height = 1,
#   width = 3
# )
# ht3$plot
ggsave(
  ht2$plot,
  filename = paste0(
    figure_save,
    "figure_07_DynamicHeatmap_Epithelial cells.pdf"
  ),
  width = 20,
  height = 10
)

p11 <- DynamicPlot(
  srt = seurat_object_Epithelial,
  lineages = c("Lineage1"),
  group.by = "Cell_subtype",
  features = c("ADAM32"),
  compare_lineages = TRUE,
  compare_features = FALSE
)
p11
ggsave(
  p11,
  filename = paste0(
    figure_save,
    "figure_08_DynamicExp_Epithelial cells.pdf"
  ),
  width = 3.5,
  height = 3.5
)



p2_1 <- CellDimPlot(
  srt = seurat_object,
  group.by = c(
    "Sample"
  ),
  label = TRUE,
  reduction = "UMAP",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
) + CellDimPlot(
  srt = seurat_object,
  group.by = c(
    "Sample"
  ),
  label = TRUE,
  reduction = "harmony",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = ""
) +
  patchwork::plot_annotation(tag_levels = "A") +
  patchwork::plot_layout(guides = "collect")

p2_1
ggsave(
  p2_1,
  filename = paste0(
    figure_save,
    "figure_1-01_CellDimPlot&CellDimPlot_tLung&tL_B.pdf"
  ),
  width = 8.5,
  height = 3.5
)


p2_2 <- CellDimPlot(
  srt = seurat_object,
  group.by = c(
    "Cell_type"
  ),
  label = TRUE,
  reduction = "UMAP",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
) + FeatureDimPlot(
  srt = seurat_object,
  features = c("ADAM32"),
  reduction = "UMAP",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "",
  cells.highlight = TRUE
) +
  patchwork::plot_annotation(tag_levels = "A")

p2_2
ggsave(
  p2_2,
  filename = paste0(
    figure_save,
    "figure_1-02_CellDimPlot&FeatureDimPlot_tLung&tL_B.pdf"
  ),
  width = 8.5,
  height = 3.5
)

p2_3 <- CellDimPlot(
  srt = seurat_object,
  group.by = c(
    "Cell_type"
  ),
  label = TRUE,
  reduction = "harmony",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
) + FeatureDimPlot(
  srt = seurat_object,
  features = c("ADAM32"),
  reduction = "harmony",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "Expression level",
  cells.highlight = TRUE
) +
  patchwork::plot_annotation(tag_levels = "A")

p2_3
ggsave(
  p2_3,
  filename = paste0(
    figure_save,
    "figure_1-02_CellDimPlot&FeatureDimPlot_tLung&tL_B_harmony.pdf"
  ),
  width = 9,
  height = 5
)

### Epithelial
p2_1 <- CellDimPlot(
  srt = seurat_object_Epithelial,
  group.by = c(
    "Sample"
  ),
  label = TRUE,
  reduction = "UMAP",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
) + CellDimPlot(
  srt = seurat_object_Epithelial,
  group.by = c(
    "Sample"
  ),
  label = TRUE,
  reduction = "harmony",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = ""
) +
  patchwork::plot_annotation(tag_levels = "A") +
  patchwork::plot_layout(guides = "collect")

p2_1
ggsave(
  p2_1,
  filename = paste0(
    figure_save,
    "figure_1-01_CellDimPlot&CellDimPlot_tLung&tL_B_Epithelial.pdf"
  ),
  width = 9,
  height = 5
)


p2_2 <- CellDimPlot(
  srt = seurat_object_Epithelial,
  group.by = c(
    "Cell_subtype"
  ),
  label = TRUE,
  reduction = "UMAP",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
) + FeatureDimPlot(
  srt = seurat_object_Epithelial,
  features = c("ADAM32"),
  reduction = "UMAP",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "Expression level",
  cells.highlight = TRUE
) +
  patchwork::plot_annotation(tag_levels = "A")

p2_2
ggsave(
  p2_2,
  filename = paste0(
    figure_save,
    "figure_1-02_CellDimPlot&FeatureDimPlot_tLung&tL_B_Epithelial.pdf"
  ),
  width = 8.5,
  height = 3.5
)

p2_3 <- CellDimPlot(
  srt = seurat_object_Epithelial,
  group.by = c(
    "Cell_subtype"
  ),
  label = TRUE,
  reduction = "harmony",
  legend.position = "right",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "GSE131907"
) + FeatureDimPlot(
  srt = seurat_object_Epithelial,
  features = c("ADAM32"),
  reduction = "harmony",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  title = "",
  subtitle = "Expression level",
  cells.highlight = TRUE
) +
  patchwork::plot_annotation(tag_levels = "A")

p2_3
ggsave(
  p2_3,
  filename = paste0(
    figure_save,
    "figure_1-02_CellDimPlot&FeatureDimPlot_tLung&tL_B_Epithelial_harmony.pdf"
  ),
  width = 9,
  height = 5
)

p3_1 <- FeatureDimPlot(
  seurat_object_Epithelial,
  features = paste0("Lineage", 1),
  # lineages = paste0("Lineage", 1),
  reduction = "harmony",
  xlab = "UMAP_1",
  ylab = "UMAP_2",
  subtitle = "GSE131907"
) + DynamicPlot(
  srt = seurat_object_Epithelial,
  lineages = c("Lineage1"),
  group.by = "Cell_subtype",
  features = c("ADAM32"),
  slot = "counts",
  line.size = 2,
  pt.size = 2,
  aspect.ratio = 1,
  compare_lineages = TRUE,
  compare_features = FALSE
) +
  patchwork::plot_annotation(tag_levels = "A")

p3_1
ggsave(
  p3_1,
  filename = paste0(
    figure_save,
    "figure_02-06_Pseudotime&DynamicExp_Epithelial cells.pdf"
  ),
  width = 7,
  height = 3.5
)



if (FALSE) {
  FeatureStatPlot(
    seurat_object_Epithelial,
    stat.by = c("ADAM32"),
    group.by = "Cell_subtype",
    comparisons = c(
      "tS1",
      "tS2"
    )
  )



  feature_metadata <- ht2$feature_metadata
  features <- feature_metadata[which(
    feature_metadata$feature_split == "C6"
  ), "features"]

  ht <- GroupHeatmap(
    srt = seurat_object,
    features = c(
      "ADAM32", features
    ),
    group.by = c(
      "Cell_subtype"
    ),
    heatmap_palette = "Reds",
    cell_annotation = c(
      "Sample",
      "Sample_Origin"
    ),
    cell_annotation_palette = c("Dark2", "Paired"),
    show_row_names = TRUE,
    row_names_side = "left",
    # feature_annotation = "highly_variable_genes",
    add_dot = TRUE, add_reticle = TRUE
  )

  print(ht$plot)
  ggsave(
    ht$plot,
    filename = paste0(
      figure_save,
      "figure_09_GroupHeatmap_Epithelial cells.pdf"
    ),
    width = 6,
    height = 8
  )


  p10 <- FeatureStatPlot(
    srt = seurat_object, group.by = "Sample",
    # bg.by = "Cell_subtype",
    stat.by = c("ADAM32"),
    #   comparisons = list(
    #     c("Ductal", "Ngn3 low EP"),
    #     c("Ngn3 high EP", "Pre-endocrine"),
    #     c("Alpha", "Beta")
    #   ),
    add_box = TRUE
  )
  p10
  ggsave(
    p10,
    filename = paste0(
      figure_save,
      "figure_10_FeatureStatPlot_Epithelial cells.pdf"
    ),
    width = 10,
    height = 5.5
  )

  p11 <- CellDimPlot(
    srt = seurat_object,
    group.by = c(
      "Sample",
      "Sample_Origin",
      # "Cell_type",
      "Cell_subtype"
    ),
    reduction = "UMAP",
    theme_use = "theme_blank",
    legend.position = "right",
    label = TRUE
  )
  p11
  ggsave(
    p11,
    filename = paste0(
      figure_save,
      "figure_11_CellDimPlot_Epithelial cells.pdf"
    ),
    width = 12,
    height = 6
  )

  seurat_object <- subset(
    seurat_object,
    subset = Sample %in% c(
      "BRONCHO_58",
      "EBUS_28", #
      "EBUS_06", #
      "LUNG_T20",
      "LUNG_T34", "LUNG_T28",
      "LUNG_T30", "LUNG_T18",
      "LUNG_T06"
    )
  )

  seurat_object <- Standard_SCP(seurat_object)

  p12 <- FeatureStatPlot(
    srt = seurat_object,
    group.by = "Sample",
    stat.by = c("ADAM32"),
    add_box = TRUE
  )
  p12
  ggsave(
    p12,
    filename = paste0(
      figure_save,
      "figure_12_FeatureStatPlot_Epithelial cells.pdf"
    ),
    width = 6,
    height = 4
  )

  seurat_object <- Integration_SCP(
    srtMerge = seurat_object,
    batch = "Sample",
    integration_method = "Harmony",
    linear_reduction_dims_use = 1:30
  )



  p13 <- CellDimPlot(
    srt = seurat_object,
    group.by = c(
      "Sample",
      "Sample_Origin",
      # "Cell_type",
      "Cell_subtype"
    ),
    reduction = "harmony",
    theme_use = "theme_blank",
    legend.position = "right",
    label = TRUE
  )
  p13
  ggsave(
    p13,
    filename = paste0(
      figure_save,
      "figure_13_CellDimPlot_Epithelial cells_integration-samples.pdf"
    ),
    width = 12,
    height = 6
  )


  seurat_object <- RunSlingshot(
    srt = seurat_object,
    group.by = "Cell_subtype",
    reduction = "harmony",
    start = "tS1"
  )

  FeatureDimPlot(
    seurat_object,
    features = paste0("Lineage", 1:2),
    reduction = "harmony",
    theme_use = "theme_blank"
  )

  seurat_object$Cell_type
  FeatureStatPlot(
    srt = seurat_object,
    group.by = "Cell_subtype",
    # bg.by = "Cell_subtype",
    stat.by = c("ADAM32"),
    #   comparisons = list(
    #     c("Ductal", "Ngn3 low EP"),
    #     c("Ngn3 high EP", "Pre-endocrine"),
    #     c("Alpha", "Beta")
    #   ),
    add_box = TRUE
  )
  seurat_object
  FeatureStatPlot(
    seurat_object,
    stat.by = c("ADAM32"),
    group.by = "Cell_subtype",
    plot_type = "bar"
  )
  FeatureStatPlot(
    seurat_object,
    stat.by = c("ADAM32"),
    group.by = "Cell_subtype",
    plot_type = "col"
  )
  FeatureStatPlot(
    seurat_object,
    stat.by = c("ADAM32"),
    group.by = "Cell_subtype",
    plot.by = "feature"
  )

  ggsave(
    filename = paste0(
      figure_save,
      "figure_12_FeatureStatPlot_Epithelial cells.pdf"
    ),
    width = 17,
    height = 5.5
  )

  CellStatPlot(
    seurat_object,
    stat.by = c("stage"),
    group.by = "Cell_subtype",
    stat_type = "count",
    plot_type = "trend"
  )
}
