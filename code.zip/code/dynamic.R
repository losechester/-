library(inferCSN)
gam_fit <- function(
    matrix,
    pseudotime,
    cores = 1,
    verbose = TRUE,
    adjust_method = "BH") {
  adjust_method <- match.arg(adjust_method, stats::p.adjust.methods)
  matrix <- t(matrix)
  res <- parallelize_fun(
    colnames(matrix),
    function(x) {
      gam_model <- suppressWarnings(
        gam::gam(
          exp ~ gam::lo(t),
          data = data.frame(
            exp = matrix[, x],
            t = pseudotime
          )
        )
      )
      data.frame(
        gene = x,
        p_value = summary(gam_model)[4][[1]][1, 5]
      )
    },
    cores = cores,
    verbose = verbose
  ) |> purrr::list_rbind()
  res$adjust_p_value <- stats::p.adjust(
    res$p_value,
    method = adjust_method
  ) |> stats::na.omit()
  res <- res[order(
    as.numeric(res$adjust_p_value),
    decreasing = FALSE
  ), ]
  
  return(res)
}


findDynGenes <- function(
    object,
    meta_data,
    celltype_by = NULL,
    group_column = "cluster",
    pseudotime_column = "pseudotime",
    cores = 1) {
  meta_data$pseudotime <- meta_data[, pseudotime_column]
  meta_data <- meta_data[which(!is.na(meta_data$pseudotime)), ]
  
  meta_data$cluster <- meta_data[, group_column]
  meta_data$cells <- rownames(meta_data)
  
  if (is.null(celltype_by)) {
    celltype_by <- unique(meta_data[, group_column])
  }
  
  meta_data <- purrr::map_dfr(
    celltype_by, function(x) {
      filter(meta_data, cluster == x)
    }
  )
  
  if (nrow(meta_data) == 0) {
    res <- list(genes = NULL, cells = NULL)
    return(res)
  }
  
  object <- object[, meta_data$cells]
  
  res <- gam_fit(
    object,
    meta_data$pseudotime,
    cores = cores
  )
  p_value <- res$adjust_p_value
  names(p_value) <- res$gene
  
  cells <- data.frame(
    cells = meta_data$cells,
    pseudotime = meta_data$pseudotime,
    group = as.vector(meta_data$cluster)
  )
  cells <- cells[order(cells$pseudotime), ]
  
  return(
    list(
      genes = p_value,
      cells = cells
    )
  )
}
