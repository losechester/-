# 安装并加载 Monocle3
# install.packages("monocle3")  # 若未安装
library(monocle3)

# 将 Seurat 对象转换为 Monocle3 的 cell_data_set 对象
if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")


# 安装并加载 Monocle3
# install.packages("monocle3")  # 若未安装
library(monocle3)
library(SeuratWrappers)

# 将 Seurat 对象转换为 Monocle3 的 cell_data_set 对象
cds <- as.cell_data_set(sc_obj)

# 预处理数据
cds <- estimate_size_factors(cds)
cds <- preprocess_cds(cds, method = "PCA")

# 使用 UMAP 降维（沿用 Seurat 的 UMAP 结果）
cds <- reduce_dimension(cds, reduction_method = "UMAP", preprocess_method = "PCA")

# 聚类和学习轨迹
cds <- cluster_cells(cds)
cds <- learn_graph(cds)

# 可视化轨迹，按细胞类型或条件着色
plot_cells(cds, color_cells_by = "cell_type", label_groups_by_cluster = T, 
           label_leaves = TRUE, label_branch_points = TRUE) +
  ggtitle("Pseudotime Trajectory by Cell Type")

plot_cells(cds, color_cells_by = "oupSample.batchCond") +
  ggtitle("Pseudotime Trajectory by Condition (AD vs. ct)")


###########################################
# 2. 从Seurat对象中提取UMAP坐标并添加到cds对象
cds@reducedDims[["UMAP"]] <- sc_obj@reductions$umap@cell.embeddings

# 3. 从Seurat对象中提取聚类信息
cds@clusters$UMAP$clusters <- sc_obj@meta.data$seurat_clusters
# 添加分区信息(使用Seurat聚类作为分区)
cds@clusters$UMAP$partitions <- sc_obj@meta.data$seurat_clusters

# 4. 处理行名和列名，确保它们匹配
cds@colData@rownames <- sc_obj@assays$RNA@data@Dimnames[[2]]

# 5. 现在可以正确执行Monocle 3的轨迹分析
# 使用预计算的UMAP进行聚类
cds <- cluster_cells(cds, reduction_method = "UMAP", cluster_method = "louvain")

# 学习轨迹图
cds <- learn_graph(cds, use_partition = TRUE)

# 可视化轨迹
plot_cells(cds, 
           color_cells_by = "cell_type", 
           label_groups_by_cluster = FALSE,
           label_leaves = FALSE,
           label_branch_points = FALSE)

# 6. 选择起始点（根节点）
# 方法1: 手动指定根节点（查看图形后确定）
# 首先查看图形上的节点
plot_cells(cds, 
           color_cells_by = "cell_type", 
           label_groups_by_cluster = FALSE,
           label_leaves = TRUE,
           label_branch_points = TRUE)

# 方法2: 基于细胞类型自动选择根节点
get_earliest_principal_node <- function(cds, cell_type) {
  cell_ids <- which(colData(cds)$cell_type == cell_type)
  
  if (length(cell_ids) == 0) {
    stop(paste0("No cells found with cell_type '", cell_type, "'"))
  }
  
  closest_vertex <- 
    cds@principal_graph_aux$UMAP$pr_graph_cell_proj_closest_vertex
  closest_vertex <- as.matrix(closest_vertex[colnames(cds), ])
  
  root_pr_nodes <- igraph::V(principal_graph(cds)[["UMAP"]])$name[
    as.numeric(names(which.max(table(closest_vertex[cell_ids,]))))]
  
  return(root_pr_nodes)
}

# 假设"astro"是起始细胞类型
root_node <- get_earliest_principal_node(cds, "astro")
print(paste0("自动选择的根节点是: ", root_node))

# 或者手动指定根节点（在查看图形后）
# root_node <- "Y_99"  # 替换为您在图中看到的合适节点ID

# 7. 计算拟时间
cds <- order_cells(cds, root_pr_nodes = root_node)

# 8. 可视化拟时间
plot_cells(cds, 
           color_cells_by = "pseudotime", 
           label_cell_groups = FALSE,
           label_leaves = FALSE,
           label_branch_points = FALSE)

# 9. 将拟时间信息添加回Seurat对象
sc_obj$monocle3_pseudotime <- pseudotime(cds)
FeaturePlot(sc_obj, features = "monocle3_pseudotime", label = FALSE) +
  scale_color_viridis_c() +
  ggtitle("Monocle 3 Pseudotime")